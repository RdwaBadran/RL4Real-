from __future__ import annotations
from typing import Any, Dict, List, Optional, Tuple
import random
from app.environments.base import BaseEnvironment

class Gym4ReaL(BaseEnvironment):
    """
    A tiny "training sim" environment inspired by Gym4ReaL-style HUD:
    - You control an agent in a grid and must reach the goal before Energy hits 0.
    - Actions: 0=Rest, 1=Walk, 2=Focus
      * Rest: stay, regain energy a bit
      * Walk: move randomly (simulates exploration)
      * Focus: move greedily toward the goal (simulates deliberate effort)
    Discrete state = (position, energy_level) so *all* tabular algorithms work.
    """
    ACTIONS = ["Rest", "Walk", "Focus"]

    def __init__(self, gridSize: int = 11, maxSteps: int = 400, energyMax: int = 100, slipProb: float = 0.05):
        self.size = int(gridSize)
        if self.size < 5:
            self.size = 5
        self.max_steps = int(maxSteps)
        self.energy_max = int(energyMax)
        self.slip = float(slipProb)
        self._rng = random.Random()

        # map layout (four-rooms-ish walls)
        self.walls: set[Tuple[int,int]] = set()
        mid = self.size // 2
        for i in range(self.size):
            if i != mid - 1:
                self.walls.add((mid, i))
            if i != mid + 1:
                self.walls.add((i, mid))

        # start / goal
        self.start = (1, 1)
        self.goal = (self.size - 2, self.size - 2)

        self.pos = self.start
        self.energy = self.energy_max
        self.t = 0

        self._P_cache: Optional[Dict[int, Dict[int, List[Tuple[float,int,float,bool]]]]] = None

    def _pos_to_idx(self, pos: Tuple[int,int]) -> int:
        x, y = pos
        return y * self.size + x

    def _idx_to_pos(self, idx: int) -> Tuple[int,int]:
        x = idx % self.size
        y = idx // self.size
        return (x, y)

    def _encode(self, pos: Tuple[int,int], energy: int) -> int:
        e = max(0, min(self.energy_max, int(energy)))
        return self._pos_to_idx(pos) * (self.energy_max + 1) + e

    def _decode(self, s: int) -> Tuple[Tuple[int,int], int]:
        s = int(s)
        e = s % (self.energy_max + 1)
        p = s // (self.energy_max + 1)
        return self._idx_to_pos(p), e

    def get_metadata(self) -> Dict[str, Any]:
        return {
            "type": "grid",
            "draw_mode": "gym4real",
            "size": self.size,
            "start": {"x": self.start[0], "y": self.start[1]},
            "goal": {"x": self.goal[0], "y": self.goal[1]},
            "walls": [{"x": x, "y": y} for x, y in sorted(self.walls)],
            "actions": self.ACTIONS,
            "energyMax": self.energy_max,
        }

    def get_state_space(self) -> int:
        return (self.size * self.size) * (self.energy_max + 1)

    def get_action_space(self) -> int:
        return len(self.ACTIONS)

    def reset(self, seed: Optional[int] = None):
        if seed is not None:
            self._rng.seed(int(seed))
        self.pos = self.start
        self.energy = self.energy_max
        self.t = 0
        return self._encode(self.pos, self.energy)

    def _try_move(self, dx: int, dy: int, pos: Tuple[int,int]) -> Tuple[int,int]:
        nx, ny = pos[0] + dx, pos[1] + dy
        if nx < 0 or ny < 0 or nx >= self.size or ny >= self.size:
            return pos
        if (nx, ny) in self.walls:
            return pos
        return (nx, ny)

    def step(self, action: int):
        action = int(action)
        self.t += 1

        # slip: sometimes swap Walk<->Focus (simulate distraction)
        if self._rng.random() < self.slip:
            if action == 1:
                action = 2
            elif action == 2:
                action = 1

        reward = -1.0
        done = False

        if action == 0:  # Rest
            self.energy = min(self.energy_max, self.energy + 2)
            reward = -0.2
        elif action == 1:  # Walk (random move)
            self.energy = max(0, self.energy - 1)
            dx, dy = self._rng.choice([(0,-1),(1,0),(0,1),(-1,0)])
            self.pos = self._try_move(dx, dy, self.pos)
        else:  # Focus (greedy toward goal)
            self.energy = max(0, self.energy - 1)
            gx, gy = self.goal
            x, y = self.pos
            choices = []
            if gx > x: choices.append((1,0))
            if gx < x: choices.append((-1,0))
            if gy > y: choices.append((0,1))
            if gy < y: choices.append((0,-1))
            if not choices:
                choices = [(0,0)]
            dx, dy = choices[0]
            self.pos = self._try_move(dx, dy, self.pos)
            reward = -0.5

        # terminal checks
        if self.pos == self.goal:
            reward = 100.0
            done = True
        if self.energy <= 0:
            reward = -10.0
            done = True
        if self.t >= self.max_steps:
            done = True

        s = self._encode(self.pos, self.energy)
        return s, reward, done, {}

    def state_to_xy(self, state: int):
        pos, _e = self._decode(state)
        return float(pos[0]), float(pos[1])

    def state_to_hud(self, state: int):
        pos, e = self._decode(state)
        # progress based on normalized Manhattan distance to goal
        dist = abs(self.goal[0]-pos[0]) + abs(self.goal[1]-pos[1])
        maxd = (self.size-1)*2
        progress = 1.0 - (dist/maxd if maxd>0 else 0.0)
        return {"energy": int(e), "progress": float(max(0.0,min(1.0,progress)))}

    def get_transition_model(self):
        # Build explicit P[s][a] = list(prob, ns, r, done) for planning algorithms.
        # This can be large; we cache it per environment instance.
        if self._P_cache is not None:
            return self._P_cache

        nS = self.get_state_space()
        nA = self.get_action_space()
        P: Dict[int, Dict[int, List[Tuple[float,int,float,bool]]]] = {s: {a: [] for a in range(nA)} for s in range(nS)}

        def clamp_energy(e: int) -> int:
            return max(0, min(self.energy_max, e))

        for s in range(nS):
            (pos, e) = self._decode(s)
            for a in range(nA):
                # for a==1 or 2 there is slip between them
                actions_to_consider = [(a, 1.0)]
                if a in (1,2) and self.slip > 0:
                    actions_to_consider = [(a, 1.0 - self.slip), (1 if a==2 else 2, self.slip)]

                outcomes: Dict[int, Tuple[float,float,bool]] = {}
                for real_a, p_a in actions_to_consider:
                    if real_a == 0:
                        ne = clamp_energy(e + 2)
                        npos = pos
                        r = -0.2
                        done = False
                        if npos == self.goal:
                            r = 100.0; done = True
                        if ne <= 0:
                            r = -10.0; done = True
                        ns = self._encode(npos, ne)
                        prev = outcomes.get(ns, (0.0, 0.0, False))
                        outcomes[ns] = (prev[0] + p_a, r, done)
                    elif real_a == 1:
                        ne = clamp_energy(e - 1)
                        # Walk: uniform random over 4 moves
                        for dx,dy in [(0,-1),(1,0),(0,1),(-1,0)]:
                            npos = self._try_move(dx, dy, pos)
                            r = -1.0
                            done = False
                            if npos == self.goal:
                                r = 100.0; done = True
                            if ne <= 0:
                                r = -10.0; done = True
                            ns = self._encode(npos, ne)
                            prev = outcomes.get(ns, (0.0, 0.0, False))
                            outcomes[ns] = (prev[0] + p_a*(0.25), r, done)
                    else:
                        ne = clamp_energy(e - 1)
                        gx, gy = self.goal
                        x, y = pos
                        # greedy: choose first axis toward goal (deterministic)
                        if gx > x: dx, dy = 1, 0
                        elif gx < x: dx, dy = -1, 0
                        elif gy > y: dx, dy = 0, 1
                        elif gy < y: dx, dy = 0, -1
                        else: dx, dy = 0, 0
                        npos = self._try_move(dx, dy, pos)
                        r = -0.5
                        done = False
                        if npos == self.goal:
                            r = 100.0; done = True
                        if ne <= 0:
                            r = -10.0; done = True
                        ns = self._encode(npos, ne)
                        prev = outcomes.get(ns, (0.0, 0.0, False))
                        outcomes[ns] = (prev[0] + p_a, r, done)

                # time limit isn't modeled in P (acceptable for planning demo)
                P[s][a] = [(prob, ns, float(r), bool(done)) for ns,(prob,r,done) in outcomes.items()]

        self._P_cache = P
        return P
