from app.environments.gridworld import GridWorld
from app.environments.frozen_lake import FrozenLake
from app.environments.cartpole import CartPole
from app.environments.breakout import Breakout
from app.environments.gym4real import Gym4ReaL
from app.environments.mountain_car import MountainCar

ENV_REGISTRY = {
    "GridWorld": GridWorld,
    "FrozenLake": FrozenLake,
    "CartPole": CartPole,
    "Breakout": Breakout,
    "Gym4ReaL": Gym4ReaL,
    "MountainCar": MountainCar,
}
