from __future__ import annotations
from typing import Any, Dict, List, Tuple, Optional

class BaseTrainer:
    def __init__(self, env):
        self.env = env

    def metadata(self)->Dict[str,Any]:
        return self.env.get_metadata()

    def state_to_xy(self, state:int)->Tuple[float,float]:
        return self.env.state_to_xy(state)

    def rollout(self, agent, max_steps:int=200, seed: Optional[int] = None)->List[Dict[str,float]]:
        path=[]
        try:
            s = self.env.reset(seed=seed) if seed is not None else self.env.reset()
        except TypeError:
            s = self.env.reset()
        for _ in range(int(max_steps)):
            x,y=self.state_to_xy(s)
            point={"x": float(x), "y": float(y)}
            if hasattr(self.env,"state_to_hud"):
                try:
                    point.update(self.env.state_to_hud(s))
                except Exception:
                    pass
            path.append(point)
            a = agent.act(s, greedy=True) if hasattr(agent,"act") else 0
            s,r,done,_ = self.env.step(a)
            if done:
                x,y=self.state_to_xy(s)
                point={"x": float(x), "y": float(y)}
                if hasattr(self.env,"state_to_hud"):
                    try:
                        point.update(self.env.state_to_hud(s))
                    except Exception:
                        pass
                path.append(point)
                break
        return path
