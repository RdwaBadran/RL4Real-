from __future__ import annotations
from typing import Any, Dict, List
from app.algorithms.base import BaseRLAgent

class PolicyIteration(BaseRLAgent):
    def __init__(self, n_states:int, n_actions:int, gamma:float=0.99, theta:float=1e-6, eval_iterations:int=50):
        super().__init__(n_states,n_actions,gamma)
        self.theta=float(theta)
        self.eval_iterations=int(eval_iterations)
        self.V=[0.0]*self.n_states
        self.pi=[0]*self.n_states

    def act(self,state:int,greedy:bool=False,epsilon:float=0.0)->int:
        return self.pi[int(state)] if int(state)<len(self.pi) else 0

    def train(self, env, iterations:int=50, **_)->Dict[str,Any]:
        P=env.get_transition_model()
        if P is None:
            raise ValueError("Environment does not provide transition model required for policy_iteration")
        stable_steps=[]
        for it in range(int(iterations)):
            # policy evaluation
            for _ in range(self.eval_iterations):
                delta=0.0
                for s in range(self.n_states):
                    v=self.V[s]
                    a=self.pi[s]
                    nv=0.0
                    for prob,ns,r,done in P[s][a]:
                        nv += prob*(r + (0.0 if done else self.gamma*self.V[ns]))
                    self.V[s]=nv
                    delta=max(delta, abs(v-nv))
                if delta<self.theta:
                    break
            # policy improvement
            stable=True
            for s in range(self.n_states):
                old=self.pi[s]
                qmax=-1e18; best_a=old
                for a in range(self.n_actions):
                    q=0.0
                    for prob,ns,r,done in P[s][a]:
                        q += prob*(r + (0.0 if done else self.gamma*self.V[ns]))
                    if q>qmax:
                        qmax=q; best_a=a
                self.pi[s]=best_a
                if best_a!=old:
                    stable=False
            stable_steps.append(1 if stable else 0)
            if stable:
                break
        return {"stable_flags": stable_steps}

    def get_policy(self):
        return {s:a for s,a in enumerate(self.pi)}
