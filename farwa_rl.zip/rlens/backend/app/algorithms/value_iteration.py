from __future__ import annotations
from typing import Any, Dict, List
import math
from app.algorithms.base import BaseRLAgent

class ValueIteration(BaseRLAgent):
    def __init__(self, n_states:int, n_actions:int, gamma:float=0.99, theta:float=1e-6):
        super().__init__(n_states,n_actions,gamma)
        self.theta=float(theta)
        self.V=[0.0]*self.n_states
        self.pi=[0]*self.n_states

    def act(self,state:int,greedy:bool=False,epsilon:float=0.0)->int:
        return self.pi[int(state)] if int(state)<len(self.pi) else 0

    def train(self, env, iterations:int=200, **_)->Dict[str,Any]:
        P=env.get_transition_model()
        if P is None:
            raise ValueError("Environment does not provide transition model required for value_iteration")
        history=[]
        for _ in range(int(iterations)):
            delta=0.0
            for s in range(self.n_states):
                v=self.V[s]
                qmax=-1e18; best_a=0
                for a in range(self.n_actions):
                    q=0.0
                    for prob,ns,r,done in P[s][a]:
                        q += prob*(r + (0.0 if done else self.gamma*self.V[ns]))
                    if q>qmax:
                        qmax=q; best_a=a
                self.V[s]=qmax
                self.pi[s]=best_a
                delta=max(delta, abs(v-qmax))
            history.append(delta)
            if delta < self.theta:
                break
        return {"deltas": history}

    def get_policy(self):
        return {s:a for s,a in enumerate(self.pi)}
