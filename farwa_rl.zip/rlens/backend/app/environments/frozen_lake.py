from __future__ import annotations
from typing import Any, Dict, List, Tuple, Optional
import random
from app.environments.base import BaseEnvironment

class FrozenLake(BaseEnvironment):
    """Tiny frozen-lake-like grid with holes. Discrete MDP."""
    ACTIONS = [(0,-1),(1,0),(0,1),(-1,0)]

    def __init__(self, gridSize:int=4, slipProb:float=0.1, maxSteps:int=200):
        self.size=int(gridSize)
        self.slip=float(slipProb)
        self.max_steps=int(maxSteps)
        # simple default holes
        self.holes=set()
        if self.size>=4:
            self.holes={(1,1),(3,1),(3,2),(0,3)}
        self.reset()

    def _encode(self,x,y): return y*self.size+x
    def _decode(self,s): return s%self.size, s//self.size

    def reset(self, seed: Optional[int] = None)->int:
        if seed is not None:
            random.seed(int(seed))
        self.x,self.y=0,0
        self.t=0
        return self._encode(self.x,self.y)

    
    def step(self, action:int):
        self.t += 1
        if random.random() < self.slip:
            action = random.randrange(4)
        dx,dy = self.ACTIONS[int(action)]
        nx = min(self.size-1, max(0, self.x+dx))
        ny = min(self.size-1, max(0, self.y+dy))

        # Holes act like blocked tiles: you cannot move into them.
        if (nx,ny) in self.holes:
            nx,ny = self.x,self.y

        self.x,self.y = nx,ny
        done = (nx==self.size-1 and ny==self.size-1) or self.t>=self.max_steps
        reward = 1.0 if (nx==self.size-1 and ny==self.size-1) else -0.01
        return self._encode(nx,ny), reward, done, {}

    def get_state_space(self)->int: return self.size*self.size
    def get_action_space(self)->int: return 4

    def state_to_xy(self, state:int):
        x,y=self._decode(int(state))
        return float(x), float(y)

    def get_metadata(self)->Dict[str,Any]:
        return {
            "name":"FrozenLake",
            "draw_mode":"grid",
            "gridSize": self.size,
            "slipProb": self.slip,
            "maxSteps": self.max_steps,
            "actions":["up","right","down","left"],
            "start":{"x": 0, "y": 0},
            "goal":{"x": self.size-1, "y": self.size-1},
            "holes":[{"x":x,"y":y} for (x,y) in sorted(self.holes)],
        }

    def get_transition_model(self):
        """Transition model for planning algorithms (Value/Policy Iteration)."""
        nS = self.get_state_space()
        nA = self.get_action_space()
        P = [[[] for _ in range(nA)] for __ in range(nS)]
        for s in range(nS):
            x, y = self._decode(s)
            terminal = (x == self.size-1 and y == self.size-1)
            for a in range(nA):
                if terminal:
                    P[s][a] = [(1.0, s, 0.0, True)]
                    continue
                outcomes = []
                for a2, prob in self._action_distribution(a):
                    dx, dy = self.ACTIONS[int(a2)]
                    nx = min(self.size-1, max(0, x + dx))
                    ny = min(self.size-1, max(0, y + dy))
                    # Holes are blocked: can't enter
                    if (nx, ny) in self.holes:
                        nx, ny = x, y
                    ns = self._encode(nx, ny)
                    done = (nx == self.size-1 and ny == self.size-1)
                    r = 1.0 if done else -0.01
                    outcomes.append((prob, ns, r, done))
                P[s][a] = outcomes
        return P

    def _action_distribution(self,intended):
        sp=self.slip
        if sp<=0: return [(intended,1.0)]
        other=sp/3.0
        return [(a,(1.0-sp) if a==intended else other) for a in range(4)]

    @staticmethod
    def _merge_outcomes(outcomes):
        acc={}
        for p,ns,r,d in outcomes:
            key=(ns,r,d)
            acc[key]=acc.get(key,0.0)+p
        return [(p,ns,r,d) for (ns,r,d),p in acc.items()]
