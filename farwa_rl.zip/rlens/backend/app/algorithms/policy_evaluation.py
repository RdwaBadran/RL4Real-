from __future__ import annotations
from typing import Any, Dict, List, Optional
import random

from app.algorithms.base import BaseRLAgent


class PolicyEvaluation(BaseRLAgent):
    def __init__(
        self,
        n_states: int,
        n_actions: int,
        gamma: float = 0.99,
        theta: float = 1e-6,
        maxIterations: int = 10_000,
        seed: Optional[int] = None,
        **_,
    ):
        super().__init__(n_states, n_actions, gamma=gamma)

        self.theta = float(theta)
        self.max_iterations = int(maxIterations)
        self._rng = random.Random(seed)

        self.policy: List[List[float]] = [
            [1.0 / float(self.n_actions) for _ in range(self.n_actions)]
            for _ in range(self.n_states)
        ]
        self.V: List[float] = [0.0 for _ in range(self.n_states)]

    def act(self, state: int, greedy: bool = True) -> int:
        s = int(state)
        probs = self.policy[s]
        r = self._rng.random()
        c = 0.0
        for a, p in enumerate(probs):
            c += p
            if r <= c:
                return int(a)
        return int(self.n_actions - 1)

    def train(self, env, episodes: int = 0, **_) -> Dict[str, Any]:
        if not hasattr(env, "get_transition_model"):
            raise ValueError("PolicyEvaluation requires env.get_transition_model()")

        transition = env.get_transition_model()
        history: List[float] = []

        for _ in range(self.max_iterations):
            delta = 0.0
            for s in range(self.n_states):
                v_old = self.V[s]
                new_v = 0.0
                for a in range(self.n_actions):
                    pi = self.policy[s][a]
                    for t in transition[s][a]:
                        if len(t) == 3:
                            ns, r, p = t
                            done = False
                        else:
                            p, ns, r, done = t

                        ns_i = int(ns)
                        new_v += pi * float(p) * (
                            float(r) + (0.0 if done else self.gamma * self.V[ns_i])
                        )

                self.V[s] = new_v
                delta = max(delta, abs(v_old - new_v))

            history.append(float(delta))
            if delta < self.theta:
                break

        return {
            "history": history,
            "value_function": self.V,
            "iterations": len(history),
        }
