from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple, Optional

class BaseEnvironment:
    """Minimal RL environment interface (discrete state/action).
    - reset() -> state (int)
    - step(action:int) -> next_state:int, reward:float, done:bool, info:dict
    """
    def reset(self, seed: Optional[int] = None) -> int:
        raise NotImplementedError

    def step(self, action: int) -> Tuple[int, float, bool, Dict[str, Any]]:
        raise NotImplementedError

    def get_state_space(self) -> int:
        """Number of discrete states."""
        raise NotImplementedError

    def get_action_space(self) -> int:
        """Number of discrete actions."""
        raise NotImplementedError

    def get_metadata(self) -> Dict[str, Any]:
        """Visualization + config metadata returned to frontend."""
        return {}

    # For model-based algorithms (value/policy iteration)
    def get_transition_model(self):
        """Return transition dict P[s][a] -> list[(prob,next_s,reward,done)]."""
        return None

    # For visualization paths
    def state_to_xy(self, state: int) -> Tuple[float, float]:
        return float(state), 0.0
