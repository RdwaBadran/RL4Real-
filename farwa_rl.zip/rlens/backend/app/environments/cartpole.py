from __future__ import annotations
from typing import Any, Dict, Optional
import math, random
from app.environments.base import BaseEnvironment

class CartPole(BaseEnvironment):
    """Discretized CartPole (toy dynamics). Works with all algorithms."""
    def __init__(self, x_bins:int=10, angle_bins:int=12, maxSteps:int=200):
        self.x_bins=int(x_bins)
        self.angle_bins=int(angle_bins)
        self.max_steps=int(maxSteps)
        self.min_x=-2.4; self.max_x=2.4
        self.min_ang=-0.209; self.max_ang=0.209
        self.reset()

    def reset(self, seed: Optional[int] = None)->int:
        if seed is not None:
            random.seed(int(seed))
        self.x=0.0
        self.xdot=0.0
        self.ang=random.uniform(-0.05,0.05)
        self.angdot=0.0
        self.t=0
        return self._disc(self.x,self.ang)

    def step(self, action:int):
        self.t += 1
        self.x, self.xdot, self.ang, self.angdot, r, done = self._transition(
            self.x, self.xdot, self.ang, self.angdot, int(action), self.t
        )
        return self._disc(self.x,self.ang), float(r), bool(done), {}

    def _transition(self, x, xdot, ang, angdot, action, t):
        force = -10.0 if action==0 else 10.0
        xdot = xdot + 0.01*force
        x = x + 0.02*xdot
        angdot = angdot + 0.001*force - 0.02*math.sin(ang)
        ang = ang + 0.02*angdot
        done = abs(x) > self.max_x or abs(ang) > self.max_ang or t>=self.max_steps
        reward = 1.0 if not done else -1.0
        return x, xdot, ang, angdot, float(reward), bool(done)

    def get_state_space(self)->int: return self.x_bins*self.angle_bins
    def get_action_space(self)->int: return 2

    def _bin(self,v,vmin,vmax,bins):
        r=(v-vmin)/(vmax-vmin)
        b=int(r*bins)
        return max(0, min(bins-1, b))

    def _disc(self,x,ang)->int:
        xb=self._bin(x,self.min_x,self.max_x,self.x_bins)
        ab=self._bin(ang,self.min_ang,self.max_ang,self.angle_bins)
        return ab*self.x_bins + xb

    def _undisc(self,s:int):
        xb=s%self.x_bins
        ab=s//self.x_bins
        x=self.min_x + (xb+0.5)*(self.max_x-self.min_x)/self.x_bins
        ang=self.min_ang + (ab+0.5)*(self.max_ang-self.min_ang)/self.angle_bins
        return x, ang

    def state_to_xy(self,state:int):
        x,_=self._undisc(int(state))
        nx=(x-self.min_x)/(self.max_x-self.min_x)
        return float(nx), 0.5

    
    def state_to_hud(self, state:int):
        # Provide extra info for rendering (pole angle in radians, normalized cart x)
        x, ang = self._undisc(int(state))
        nx = (x-self.min_x)/(self.max_x-self.min_x)
        return {"cart_x": float(max(0.0, min(1.0, nx))), "angle": float(ang)}

    def get_metadata(self)->Dict[str,Any]:
        return {
            "name":"CartPole",
            "draw_mode":"track",
            "xBins": self.x_bins,
            "angleBins": self.angle_bins,
            "maxSteps": self.max_steps,
            "actions":["left","right"],
        }

    def get_transition_model(self):
        nS=self.get_state_space(); nA=self.get_action_space()
        P=[[[] for _ in range(nA)] for __ in range(nS)]
        for s in range(nS):
            x,ang=self._undisc(s)
            for a in range(nA):
                nx,nxdot,nang,nangdot,r,done = self._transition(x,0.0,ang,0.0,a,1)
                ns=self._disc(nx,nang)
                P[s][a]=[(1.0, ns, float(r), bool(done))]
        return P
