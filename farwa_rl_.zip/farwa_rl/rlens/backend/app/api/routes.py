from __future__ import annotations
from typing import Any, Dict
from fastapi import APIRouter, HTTPException
import random
import inspect
import numpy as np

from app.schemas.request import TrainingRequest
from app.environments import ENV_REGISTRY
from app.algorithms import ALGORITHM_REGISTRY
from app.trainers.env_trainers import TRAINER_REGISTRY

router = APIRouter()

def _merge_params(req: TrainingRequest) -> Dict[str, Any]:
    params = dict(req.params or {})
    if req.episodes is not None:
        params.setdefault("episodes", req.episodes)
    if req.alpha is not None:
        params.setdefault("alpha", req.alpha)
    if req.gamma is not None:
        params.setdefault("gamma", req.gamma)
    if req.epsilon is not None:
        params.setdefault("epsilon", req.epsilon)
    if req.seed is not None:
        params.setdefault("seed", int(req.seed))
    return params

@router.get("/")
def root():
    return {"status": "ok", "docs": "/docs"}

@router.get("/health")
def health():
    return {"ok": True}

@router.get("/environments")
def list_environments():
    return {"environments": sorted(list(ENV_REGISTRY.keys()))}

@router.get("/algorithms")
def list_algorithms():
    return {"algorithms": sorted(list(ALGORITHM_REGISTRY.keys()))}

@router.post("/run")
def run_training(req: TrainingRequest):
    params = _merge_params(req)

    seed = params.get("seed", None)
    if seed is not None:
        try:
            seed = int(seed)
        except Exception:
            raise HTTPException(status_code=400, detail="seed must be an integer")
        random.seed(seed)
        np.random.seed(seed)

    env_name = req.environment
    alg_name = req.algorithm

    if env_name not in ENV_REGISTRY:
        raise HTTPException(status_code=400, detail=f"Unknown environment: {env_name}")
    if alg_name not in ALGORITHM_REGISTRY:
        raise HTTPException(status_code=400, detail=f"Unknown algorithm: {alg_name}")

    env_cls = ENV_REGISTRY[env_name]

    candidate_kwargs: Dict[str, Any] = {}

    if "gridSize" in params: candidate_kwargs["gridSize"] = int(params["gridSize"])
    if "slipProb" in params: candidate_kwargs["slipProb"] = float(params["slipProb"])
    if "maxSteps" in params: candidate_kwargs["maxSteps"] = int(params["maxSteps"])

    if "width" in params: candidate_kwargs["width"] = int(params["width"])
    if "height" in params: candidate_kwargs["height"] = int(params["height"])
    if "brickRows" in params: candidate_kwargs["brick_rows"] = int(params["brickRows"])

    if "xBins" in params: candidate_kwargs["x_bins"] = int(params["xBins"])
    if "angleBins" in params: candidate_kwargs["angle_bins"] = int(params["angleBins"])

    if "posBins" in params: candidate_kwargs["pos_bins"] = int(params["posBins"])
    if "velBins" in params: candidate_kwargs["vel_bins"] = int(params["velBins"])

    sig = inspect.signature(env_cls.__init__)
    allowed = set(sig.parameters.keys())
    allowed.discard("self")
    env_kwargs = {k: v for k, v in candidate_kwargs.items() if k in allowed}

    try:
        env = env_cls(**env_kwargs)
    except TypeError as e:
        raise HTTPException(status_code=400, detail=f"Bad environment params: {e}")

    try:
        if seed is not None:
            env.reset(seed=seed)
    except TypeError:
        pass

    n_states = env.get_state_space()
    n_actions = env.get_action_space()

    alg_cls = ALGORITHM_REGISTRY[alg_name]
    gamma = float(params.get("gamma", 0.99))

    try:
        if alg_name in ("value_iteration", "policy_iteration"):
            theta = float(params.get("theta", 1e-6))
            agent = alg_cls(n_states, n_actions, gamma=gamma, theta=theta)  # type: ignore
            hist = agent.train(env, iterations=int(params.get("iterations", 200)))
        elif alg_name == "policy_evaluation":
            theta = float(params.get("theta", 1e-6))
            max_iters = int(params.get("maxIterations", params.get("iterations", 10_000)))
            agent = alg_cls(
                n_states, n_actions,
                gamma=gamma,
                theta=theta,
                maxIterations=max_iters,
                seed=seed,
            )  # type: ignore
            hist = agent.train(env)
        elif alg_name == "n_step_td":
            agent = alg_cls(
                n_states, n_actions,
                n=int(params.get("n", 3)),
                alpha=float(params.get("alpha", 0.1)),
                gamma=gamma,
                epsilon=float(params.get("epsilon", 0.1)),
            )
            hist = agent.train(env, episodes=int(params.get("episodes", 200)), max_steps=int(params.get("maxSteps", 200)))
        elif alg_name == "td0":
            agent = alg_cls(
                n_states, n_actions,
                alpha=float(params.get("alpha", 0.1)),
                gamma=gamma,
                epsilon=float(params.get("epsilon", 0.1)),
            )
            hist = agent.train(env, episodes=int(params.get("episodes", 200)), max_steps=int(params.get("maxSteps", 200)))
        else:
            kwargs = {}
            if "alpha" in params: kwargs["alpha"] = float(params["alpha"])
            if "epsilon" in params: kwargs["epsilon"] = float(params["epsilon"])
            agent = alg_cls(n_states, n_actions, gamma=gamma, **kwargs)  # type: ignore
            hist = agent.train(env, episodes=int(params.get("episodes", 200)), max_steps=int(params.get("maxSteps", 200)))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Training failed: {e}")

    trainer_cls = TRAINER_REGISTRY.get(env_name, None)
    trainer = trainer_cls(env) if trainer_cls else None
    path = trainer.rollout(agent, max_steps=int(params.get("maxSteps", 200)), seed=seed) if trainer else []

    return {
        "environment": env_name,
        "algorithm": alg_name,
        "params": params,
        "history": hist,
        "path": path,
        "metadata": env.get_metadata(),
    }
