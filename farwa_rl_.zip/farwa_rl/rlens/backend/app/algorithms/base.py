from __future__ import annotations
from typing import Any, Dict, List, Optional
import random

class BaseRLAgent:
    def __init__(self, n_states: int, n_actions: int, gamma: float = 0.99):
        self.n_states = int(n_states)
        self.n_actions = int(n_actions)
        self.gamma = float(gamma)

    def act(self, state: int, greedy: bool = False, epsilon: float = 0.1) -> int:
        raise NotImplementedError

    def train(self, env, **params) -> Dict[str, Any]:
        raise NotImplementedError

    def get_policy(self):
        return None
