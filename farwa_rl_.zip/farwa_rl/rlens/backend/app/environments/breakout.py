from __future__ import annotations
from typing import Any, Dict, Optional
import random
from app.environments.base import BaseEnvironment

class Breakout(BaseEnvironment):
    """Tiny discrete Breakout.
    State = (ball_x, ball_y, vx, vy, paddle_x, bricks_mask)
    This is small enough for planning if you keep width<=5 and brick_rows<=2.
    """
    def __init__(self, width:int=6, height:int=8, brick_rows:int=2, maxSteps:int=300):
        self.w=int(width); self.h=int(height)
        self.brick_rows=int(brick_rows)
        self.max_steps=int(maxSteps)
        self.reset()

    def _mask_bits(self):
        return self.w*self.brick_rows

    def get_action_space(self)->int:
        return 3  # left, stay, right

    def get_state_space(self)->int:
        return self.w*self.h*2*2*self.w*(2**self._mask_bits())

    def _encode(self, bx,by,vx,vy,px,mask)->int:
        vx_i = 0 if vx==-1 else 1
        vy_i = 0 if vy==-1 else 1
        bits = 2**self._mask_bits()
        s = int(mask)
        s += int(px)*bits
        s += int(vy_i)*bits*self.w
        s += int(vx_i)*bits*self.w*2
        s += int(by)*bits*self.w*4
        s += int(bx)*bits*self.w*4*self.h
        return s

    def _decode(self, s:int):
        bits = 2**self._mask_bits()
        mask = s % bits
        s//=bits
        px = s % self.w; s//=self.w
        vy_i = s % 2; s//=2
        vx_i = s % 2; s//=2
        by = s % self.h; s//=self.h
        bx = s % self.w
        vx = -1 if vx_i==0 else 1
        vy = -1 if vy_i==0 else 1
        return bx,by,vx,vy,px,mask

    def reset(self, seed: Optional[int] = None)->int:
        if seed is not None:
            random.seed(int(seed))
        self.ball_x=self.w//2
        self.ball_y=self.h-3
        self.vx=random.choice([-1,1])
        self.vy=-1
        self.paddle_x=self.w//2
        self.t=0
        self.bricks_mask=(2**self._mask_bits())-1
        return self._encode(self.ball_x,self.ball_y,self.vx,self.vy,self.paddle_x,self.bricks_mask)

    def _brick_at(self, x:int, y:int, mask:int)->bool:
        if y<0 or y>=self.brick_rows: 
            return False
        bit = y*self.w + x
        return ((mask>>bit)&1) == 1

    def _set_brick(self, x:int, y:int, mask:int, val:int)->int:
        bit = y*self.w + x
        return (mask | (1<<bit)) if val else (mask & ~(1<<bit))

    def state_to_xy(self,state:int):
        bx,by,_,_,_,_ = self._decode(int(state))
        return float(bx), float(by)

    def step(self, action:int):
        self.t += 1
        s=self._encode(self.ball_x,self.ball_y,self.vx,self.vy,self.paddle_x,self.bricks_mask)
        ns, r, done = self._transition_from_state(s, int(action), self.t)
        self.ball_x,self.ball_y,self.vx,self.vy,self.paddle_x,self.bricks_mask = self._decode(ns)
        return ns, r, done, {}

    def _transition_from_state(self, state:int, action:int, t:int):
        bx,by,vx,vy,px,mask = self._decode(state)

        if action==0: px=max(0,px-1)
        elif action==2: px=min(self.w-1,px+1)

        nx=bx+vx
        ny=by+vy

        if nx<0 or nx>=self.w:
            vx*=-1
            nx=bx+vx
        if ny<0:
            vy*=-1
            ny=by+vy

        reward=-0.01
        done=False

        if 0 <= ny < self.brick_rows and self._brick_at(nx,ny,mask):
            mask = self._set_brick(nx,ny,mask,0)
            vy*=-1
            reward=0.5
            ny=by+vy

        paddle_y=self.h-1
        if ny==paddle_y and nx==px:
            vy=-1
            reward=0.1
            ny=by+vy

        if ny>=self.h:
            done=True
            reward=-1.0

        if mask==0:
            done=True
            reward=2.0

        if t>=self.max_steps:
            done=True

        ns=self._encode(nx,ny,vx,vy,px,mask)
        return ns, float(reward), bool(done)

    
    def state_to_hud(self, state:int):
        bx,by,vx,vy,px,mask = self._decode(int(state))
        return {"ball_x": float(bx), "ball_y": float(by), "paddle_x": float(px), "bricks_mask": int(mask)}

    def get_metadata(self)->Dict[str,Any]:
        return {
            "name":"Breakout",
            "draw_mode":"breakout",
            "width": self.w,
            "height": self.h,
            "brickRows": self.brick_rows,
            "maxSteps": self.max_steps,
            "actions":["left","stay","right"],
        }

    def get_transition_model(self):
        nS=self.get_state_space(); nA=self.get_action_space()
        P=[[[] for _ in range(nA)] for __ in range(nS)]
        for s in range(nS):
            for a in range(nA):
                ns,r,done = self._transition_from_state(s,a,1)
                P[s][a]=[(1.0, ns, float(r), bool(done))]
        return P
