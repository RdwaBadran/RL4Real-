from __future__ import annotations
from typing import Any, Dict, List
from collections import defaultdict, deque
import random
from app.algorithms.base import BaseRLAgent

class NStepTD(BaseRLAgent):
    def __init__(self, n_states:int, n_actions:int, n:int=3, alpha:float=0.1, gamma:float=0.99, epsilon:float=0.1):
        super().__init__(n_states,n_actions,gamma)
        self.n=int(n)
        self.alpha=float(alpha); self.epsilon=float(epsilon)
        self.V=defaultdict(float)

    def act(self, state:int, greedy:bool=False, epsilon:float|None=None)->int:
        eps=0.0 if greedy else (self.epsilon if epsilon is None else float(epsilon))
        if random.random()<eps:
            return random.randrange(self.n_actions)
        return random.randrange(self.n_actions)

    def train(self, env, episodes:int=200, max_steps:int=200, **_)->Dict[str,Any]:
        returns=[]
        for _ep in range(int(episodes)):
            s=env.reset()
            traj=[]
            total=0.0
            for _t in range(int(max_steps)):
                a=self.act(s)
                ns,r,done,_=env.step(a)
                traj.append((s,r,ns,done))
                total += r
                # update when we have n steps
                if len(traj) >= self.n:
                    G=0.0
                    for k in range(self.n):
                        G += (self.gamma**k)*traj[k][1]
                    last_ns = traj[self.n-1][2]
                    if not traj[self.n-1][3]:
                        G += (self.gamma**self.n)*self.V[last_ns]
                    s0=traj[0][0]
                    self.V[s0] += self.alpha*(G-self.V[s0])
                    traj.pop(0)
                s=ns
                if done: break
            # flush remaining
            while traj:
                G=0.0
                for k,(ss,rr,ns,dd) in enumerate(traj):
                    G += (self.gamma**k)*rr
                    if dd: break
                s0=traj[0][0]
                self.V[s0] += self.alpha*(G-self.V[s0])
                traj.pop(0)
            returns.append(total)
        return {"episode_returns": returns}
