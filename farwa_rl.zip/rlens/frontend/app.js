const API = "http://127.0.0.1:8000";

let animationTimer = null;
let lastPath = [];
let lastMetadata = null;

function $(id){ return document.getElementById(id); }

function setStatus(msg){
  const el = $("status");
  if (el) el.textContent = msg || "";
}

function bindSlider(id, valueId, formatter){
  const slider = $(id);
  const out = $(valueId);
  if (!slider || !out) return;
  const fmt = formatter || ((v)=>v);
  const update = ()=>{ out.textContent = fmt(slider.value); };
  slider.addEventListener("input", update);
  update();
}

async function fetchOptions(){
  const [envRes, algRes] = await Promise.all([
    fetch(`${API}/environments`),
    fetch(`${API}/algorithms`)
  ]);
  if (!envRes.ok) throw new Error("Failed to fetch environments");
  if (!algRes.ok) throw new Error("Failed to fetch algorithms");

  const envs = (await envRes.json()).environments || [];
  const algs = (await algRes.json()).algorithms || [];

  const envSel = $("environment");
  const algSel = $("algorithm");
  envSel.innerHTML = "";
  algSel.innerHTML = "";

  envs.forEach(e=>{
    const opt=document.createElement("option");
    opt.value=e; opt.textContent=e;
    envSel.appendChild(opt);
  });

  const friendly = {
    "q_learning":"Q-Learning",
    "sarsa":"SARSA",
    "monte_carlo":"Monte Carlo",
    "td0":"TD(0)",
    "n_step_td":"n-step TD",
    "value_iteration":"Value Iteration",
    "policy_iteration":"Policy Iteration",
    "policy_evaluation":"Policy Evaluation",
  };
  algs.forEach(a=>{
    const opt=document.createElement("option");
    opt.value=a;
    opt.textContent=friendly[a] || a;
    algSel.appendChild(opt);
  });

  // defaults
  if (envs.includes("GridWorld")) envSel.value = "GridWorld";
  if (algs.includes("q_learning")) algSel.value = "q_learning";

  envSel.addEventListener("change", onEnvironmentChange);
}

function gatherParams(){
  return {
    seed: Number($("seed")?.value ?? 0),
    // algorithm
    episodes: 200, // UI doesn't have episodes yet; keep stable default
    maxSteps: Number($("maxSteps").value),
    alpha: Number($("learningRate").value),
    gamma: Number($("discountFactor").value),
    epsilon: Number($("explorationRate").value),

    // env
    gridSize: Number($("gridSize").value),
    slipProb: Number($("slipProb").value),

    // discretization defaults (needed for CartPole/MountainCar tabular)
    xBins: 10,
    angleBins: 12,
    posBins: 18,
    velBins: 14,

    // planning defaults
    iterations: 200,
    theta: 1e-6,

    // breakout defaults (kept even if env isn't breakout)
    width: 6,
    height: 8,
    brickRows: 2,
  };
}

function stopLearning(){
  if (animationTimer) clearInterval(animationTimer);
  animationTimer = null;
  setStatus("Stopped.");
}

function resetAlgorithm(){
  $("learningRate").value = 0.1;
  $("discountFactor").value = 0.99;
  $("explorationRate").value = 0.2;
  $("exploration").value = "epsilon-greedy";
  $("learningRate").dispatchEvent(new Event("input"));
  $("discountFactor").dispatchEvent(new Event("input"));
  $("explorationRate").dispatchEvent(new Event("input"));
  setStatus("Algorithm reset.");
}

function resetEnvironment(){
  $("gridSize").value = 5;
  $("slipProb").value = 0.0;
  $("maxSteps").value = 200;
  $("speed").value = 200;
  $("gridSize").dispatchEvent(new Event("input"));
  $("slipProb").dispatchEvent(new Event("input"));
  $("maxSteps").dispatchEvent(new Event("input"));
  $("speed").dispatchEvent(new Event("input"));
  clearCanvas();
  setStatus("Environment reset.");
}

function togglePanel(id){
  const panel = document.getElementById(id);
  if (!panel) return;
  panel.classList.toggle("collapsed");
}

function clearCanvas(){
  const c = $("environmentCanvas");
  const ctx = c.getContext("2d");
  ctx.clearRect(0,0,c.width,c.height);
}

function drawGrid(ctx, md, point){
  // Original-style grid renderer (GridWorld, FrozenLake, Gym4ReaL)
  const size = Number(md.gridSize || md.size || $("gridSize")?.value || 5);
  const pad = 12;
  const w = ctx.canvas.width;
  const h = ctx.canvas.height;
  const cell = Math.floor((Math.min(w, h) - pad*2) / size);

  ctx.clearRect(0,0,w,h);

  const start = md.start || {x:0,y:0};
  const goal  = md.goal  || {x:size-1,y:size-1};
  const holes = Array.isArray(md.holes) ? md.holes : [];
  const walls = Array.isArray(md.walls) ? md.walls : [];

  function has(list, x, y){
    return list.some(p => Number(p.x)===x && Number(p.y)===y);
  }

  function cellType(x,y){
    if (x===start.x && y===start.y) return "start";
    if (x===goal.x && y===goal.y) return "goal";
    if (has(walls,x,y)) return "wall";
    if (has(holes,x,y)) return "hole";
    return "empty";
  }

  function cellColor(t){
    // soft/pastel like the original
    if (t==="start") return "#fecaca";
    if (t==="goal") return "#93c5fd";
    if (t==="hole") return "#fde68a";
    if (t==="wall") return "#fed7aa";
    return "#fef3f2";
  }

  function cellEmoji(t){
    if (t==="start") return "🏠";
    if (t==="goal") return "💎";
    if (t==="hole") return "💀";
    if (t==="wall") return "⚠️";
    return "";
  }

  // draw cells
  ctx.font = `${Math.max(14, Math.floor(cell*0.55))}px system-ui, Segoe UI Emoji, Apple Color Emoji`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  for (let y=0; y<size; y++){
    for (let x=0; x<size; x++){
      const t = cellType(x,y);
      const px = pad + x*cell;
      const py = pad + y*cell;

      ctx.fillStyle = cellColor(t);
      ctx.fillRect(px, py, cell-2, cell-2);

      ctx.strokeStyle = "rgba(0,0,0,0.08)";
      ctx.strokeRect(px, py, cell-2, cell-2);

      const e = cellEmoji(t);
      if (e){
        ctx.fillStyle = "rgba(0,0,0,0.85)";
        ctx.fillText(e, px+(cell-2)/2, py+(cell-2)/2);
      }
    }
  }

  // agent
  const ax = Math.max(0, Math.min(size-1, Math.round(point.x)));
  const ay = Math.max(0, Math.min(size-1, Math.round(point.y)));
  const apx = pad + ax*cell + (cell-2)/2;
  const apy = pad + ay*cell + (cell-2)/2;
  ctx.fillStyle = "rgba(0,0,0,0.9)";
  ctx.fillText("🤖", apx, apy);
}


function drawTrack(ctx, md, point){
  // CartPole-style renderer (matches your screenshot)
  const w = ctx.canvas.width, h = ctx.canvas.height;
  ctx.clearRect(0,0,w,h);

  // ground
  const groundY = h*0.78;
  ctx.beginPath();
  ctx.moveTo(w*0.05, groundY);
  ctx.lineTo(w*0.95, groundY);
  ctx.strokeStyle = "rgba(0,0,0,0.25)";
  ctx.lineWidth = 2;
  ctx.stroke();

  // cart
  const cartW = w*0.12, cartH = h*0.06;
  const x = (point.cart_x != null ? point.cart_x : point.x) ?? 0.5; // 0..1
  const cartX = w*0.08 + x*(w*0.84) - cartW/2;
  const cartY = groundY - cartH;
  ctx.fillStyle = "rgba(255,255,255,0.9)";
  ctx.strokeStyle = "rgba(0,0,0,0.55)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.rect(cartX, cartY, cartW, cartH);
  ctx.fill();
  ctx.stroke();

  // pole
  const angle = (point.angle != null ? point.angle : 0.0);
  const poleL = h*0.35;
  const pivotX = cartX + cartW/2;
  const pivotY = cartY;
  const tipX = pivotX + poleL*Math.sin(angle);
  const tipY = pivotY - poleL*Math.cos(angle);

  ctx.strokeStyle = "rgba(30,100,220,0.9)";
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(pivotX, pivotY);
  ctx.lineTo(tipX, tipY);
  ctx.stroke();

  ctx.fillStyle = "rgba(30,100,220,0.9)";
  ctx.beginPath();
  ctx.arc(tipX, tipY, 8, 0, Math.PI*2);
  ctx.fill();
}

function drawMountain(ctx, md, point){
  // MountainCar renderer (car moving left->right)
  const w = ctx.canvas.width, h = ctx.canvas.height;
  ctx.clearRect(0,0,w,h);

  const left = w*0.06, right = w*0.94;
  const minPos = -1.2, maxPos = 0.6;

  // mountain curve
  ctx.strokeStyle = "rgba(0,0,0,0.12)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  for (let i=0;i<=220;i++){
    const t = i/220;
    const x = left + t*(right-left);
    const pos = minPos + t*(maxPos-minPos);
    const yNorm = 0.5*(Math.sin(3*pos)+1.0); // 0..1
    const y = h*0.78 - yNorm*h*0.35;
    if (i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
  }
  ctx.stroke();

  // goal line
  const goalPos = (md && md.goal_position != null) ? md.goal_position : 0.5;
  const goalT = (goalPos - minPos) / (maxPos - minPos);
  const goalX = left + Math.max(0, Math.min(1, goalT))*(right-left);
  ctx.fillStyle = "rgba(16,185,129,0.20)";
  ctx.fillRect(goalX-4, h*0.35, 8, h*0.55);

  // car position
  // Backend may send either:
  // - point.position in world coordinates (-1.2..0.6)
  // - point.x normalized (0..1) from state_to_xy()
  // - point.x already in world coordinates
  let posVal = (point && (point.position ?? point.x)) != null ? (point.position ?? point.x) : minPos;
  // If value looks normalized, convert to world position.
  if (typeof posVal === "number" && posVal >= 0.0 && posVal <= 1.0) {
    posVal = minPos + posVal * (maxPos - minPos);
  }
  const pos = Number(posVal);
  const t = (pos - minPos)/(maxPos-minPos);
  const carX = left + Math.max(0, Math.min(1, t))*(right-left);
  const yNorm = 0.5*(Math.sin(3*pos)+1.0);
  const carY = h*0.78 - yNorm*h*0.35;

  // draw car emoji
  ctx.font = "30px system-ui, -apple-system, Segoe UI Emoji, Apple Color Emoji";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("🚗", carX, carY-14);

  // status text
  ctx.font = "14px system-ui, -apple-system, Segoe UI, Arial";
  ctx.textAlign = "left";
  ctx.textBaseline = "alphabetic";
  ctx.fillStyle = "rgba(15,23,42,0.9)";
  const v = (point && point.value != null) ? point.value : "";
  if (v !== "") ctx.fillText("Value: " + String(v), 12, 22);
}

function drawGym4Real(ctx, md, point){
  // HUD panel renderer (light mode + background)
  const w = ctx.canvas.width, h = ctx.canvas.height;
  ctx.clearRect(0,0,w,h);

  // light background
  ctx.fillStyle = "rgba(248,250,252,1)";
  ctx.fillRect(0,0,w,h);

  // card panel
  const pad = 24;
  const pw = Math.min(520, w - pad*2);
  const ph = Math.min(260, h - pad*2);
  const px = pad;
  const py = pad;
  const r = 12;

  // subtle shadow
  ctx.save();
  ctx.shadowColor = "rgba(0,0,0,0.10)";
  ctx.shadowBlur = 14;
  ctx.shadowOffsetY = 6;
  ctx.fillStyle = "rgba(255,255,255,0.98)";
  ctx.strokeStyle = "rgba(0,0,0,0.08)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(px+r, py);
  ctx.arcTo(px+pw, py, px+pw, py+ph, r);
  ctx.arcTo(px+pw, py+ph, px, py+ph, r);
  ctx.arcTo(px, py+ph, px, py, r);
  ctx.arcTo(px, py, px+pw, py, r);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.restore();

  // labels
  ctx.fillStyle = "rgba(15,23,42,0.95)";
  ctx.font = "14px system-ui, -apple-system, Segoe UI, Arial";
  ctx.fillText("Energy: " + String(point.energy ?? 0), px+18, py+38);

  // energy bar
  const barX = px+18, barY = py+50, barW = pw-36, barH = 18;
  ctx.fillStyle = "rgba(15,23,42,0.08)";
  ctx.fillRect(barX, barY, barW, barH);
  const eMax = md.energyMax ?? 10;
  const e = Math.max(0, Math.min(eMax, Number(point.energy ?? 0)));
  ctx.fillStyle = "rgba(99,102,241,0.85)";
  ctx.fillRect(barX, barY, barW*(e/eMax), barH);

  ctx.fillStyle = "rgba(15,23,42,0.95)";
  ctx.fillText("Progress: " + String(Math.round((point.progress ?? 0)*100)), px+18, py+104);

  // progress bar
  const pY = py+116;
  ctx.fillStyle = "rgba(15,23,42,0.08)";
  ctx.fillRect(barX, pY, barW, barH);
  const prog = Math.max(0, Math.min(1, Number(point.progress ?? 0)));
  ctx.fillStyle = "rgba(16,185,129,0.85)";
  ctx.fillRect(barX, pY, barW*prog, barH);

  // actions list
  ctx.fillStyle = "rgba(15,23,42,0.85)";
  const acts = (md.actions && md.actions.length) ? md.actions : ["Rest","Walk","Focus"];
  ctx.fillText("Actions: " + acts.join(" / "), px+18, py+168);
}


function drawBreakout(ctx, md, point){
  const W = Number(md.width || 6);
  const H = Number(md.height || 8);
  const rows = Number(md.brickRows || 2);

  const cw = ctx.canvas.width;
  const ch = ctx.canvas.height;
  ctx.clearRect(0,0,cw,ch);

  const pad = 24;
  const boardX = pad, boardY = pad;
  const boardW = cw - pad*2;
  const boardH = ch - pad*2;

  // background
  ctx.fillStyle = "rgba(255,255,255,0.95)";
  ctx.fillRect(0,0,cw,ch);

  // bricks
  const brickH = boardH * 0.18 / Math.max(1, rows);
  const brickGap = 6;
  const brickW = (boardW - brickGap*(W+1)) / W;

  const mask = (point.bricks_mask != null) ? Number(point.bricks_mask) : ((1<<(W*rows))-1);
  for (let r=0;r<rows;r++){
    for (let c=0;c<W;c++){
      const bit = r*W + c;
      const alive = ((mask>>bit)&1) === 1;
      if (!alive) continue;
      const x = boardX + brickGap + c*(brickW+brickGap);
      const y = boardY + brickGap + r*(brickH+brickGap);
      ctx.fillStyle = "rgba(120,160,235,0.55)";
      ctx.fillRect(x,y,brickW,brickH);
    }
  }

  // ball (black dot)
  const bx = Number(point.x ?? point.ball_x ?? 0);
  const by = Number(point.y ?? point.ball_y ?? 0);
  const ballX = boardX + (bx + 0.5) * (boardW / W);
  const ballY = boardY + (by + 0.5) * (boardH / H);
  ctx.fillStyle = "rgba(0,0,0,0.85)";
  ctx.beginPath();
  ctx.arc(ballX, ballY, Math.min(boardW/W, boardH/H)*0.20, 0, Math.PI*2);
  ctx.fill();

  // paddle (small white rect)
  const px = Number(point.paddle_x ?? Math.floor(W/2));
  const pW = boardW / W * 1.2;
  const pH = boardH / H * 0.25;
  const paddleX = boardX + (px + 0.5) * (boardW / W) - pW/2;
  const paddleY = boardY + boardH - pH - 10;
  ctx.fillStyle = "rgba(255,255,255,0.9)";
  ctx.strokeStyle = "rgba(0,0,0,0.25)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.rect(paddleX, paddleY, pW, pH);
  ctx.fill();
  ctx.stroke();
}

function drawPoint(point){
  const c = $("environmentCanvas");
  const ctx = c.getContext("2d");
  const md = lastMetadata || {};
  const mode = md.draw_mode || "grid";

  if (mode === "grid") return drawGrid(ctx, md, point);
  if (mode === "gym4real") return drawGym4Real(ctx, md, point);
  if (mode === "track") return drawTrack(ctx, md, point);
  if (mode === "mountain") return drawMountain(ctx, md, point);
  if (mode === "breakout") return drawBreakout(ctx, md, point);
  return drawGrid(ctx, md, point);
}

function animatePath(path){
  stopLearning();
  if (!path || path.length === 0){
    setStatus("No path returned from backend.");
    return;
  }
  lastPath = path;
  let i = 0;
  const speed = Number($("speed").value);

  // draw first frame immediately
  drawPoint(path[0]);

  animationTimer = setInterval(()=>{
    if (i >= path.length){
      stopLearning();
      setStatus("Done.");
      return;
    }
    drawPoint(path[i]);
    i++;
  }, Math.max(20, speed));
}

async function startLearning(){
  stopLearning();
  setStatus("Training...");
  const env = $("environment").value;
  const algorithm = $("algorithm").value;
  const params = gatherParams();

  try{
    const res = await fetch(`${API}/run`,{
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ environment: env, algorithm, params })
    });
    if (!res.ok){
      const err = await res.json().catch(()=>({detail:"Unknown error"}));
      setStatus(`Error: ${err.detail || "Training failed"}`);
      return;
    }
    const data = await res.json();
    lastMetadata = data.metadata || {};
    setStatus("Animating learned behavior...");
    animatePath(data.path || []);
    drawLearningCurve(data.history || [], params.alpha);
  }catch(e){
    setStatus("Could not reach backend. Start FastAPI on 127.0.0.1:8000");
  }
}



function drawLearningCurve(history, alpha){
  // This chart demonstrates how different learning rates affect convergence.
  // It always draws 4 reference curves (very-high/high/low/good) like the example image.
  // If we also have real training history, we overlay it as a thick black curve.
  const c = $("learningCanvas");
  if(!c) return;
  const ctx = c.getContext("2d");

  // clear background
  ctx.clearRect(0,0,c.width,c.height);
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0,0,c.width,c.height);

  // axes
  const padL = 42, padR = 10, padT = 12, padB = 28;
  const W = c.width - padL - padR;
  const H = c.height - padT - padB;

  ctx.strokeStyle = "#111827";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(padL, padT);
  ctx.lineTo(padL, padT+H);
  ctx.lineTo(padL+W, padT+H);
  ctx.stroke();

  // labels
  ctx.fillStyle="#111827";
  ctx.font="12px system-ui, -apple-system, Segoe UI, Roboto, Arial";
  ctx.fillText("loss", 8, padT+12);
  ctx.fillText("epoch", padL+W-36, padT+H+22);

  // generate 4 curves
  const N = 80;
  function curve(kind){
    const arr=[];
    for(let i=0;i<N;i++){
      const t=i/(N-1);
      let y;
      // use simple stability models
      if(kind==="low"){
        y = 0.95*Math.exp(-2.0*t) + 0.06; // slow
      } else if(kind==="good"){
        y = 0.95*Math.exp(-7.0*t) + 0.03; // fast + stable
      } else if(kind==="high"){
        y = 0.55*Math.exp(-6.0*t) + 0.06 + 0.12*Math.abs(Math.sin(10*t)); // oscillation
      } else { // very_high
        y = 0.25 + 1.2*t*t; // diverge
      }
      arr.push(y);
    }
    return arr;
  }

  const curves = [
    {label:"very high learning rate", kind:"very_high", stroke:"#f59e0b"},
    {label:"low learning rate", kind:"low", stroke:"#2563eb"},
    {label:"high learning rate", kind:"high", stroke:"#16a34a"},
    {label:"good learning rate", kind:"good", stroke:"#dc2626"},
  ];

  // map y to plot range
  // compute max y among reference + history overlay
  let ymax = 0;
  const refData = {};
  for(const c1 of curves){
    refData[c1.kind] = curve(c1.kind);
    for(const y of refData[c1.kind]) ymax = Math.max(ymax, y);
  }
  if(history && history.length){
    for(const v of history) ymax = Math.max(ymax, Math.abs(v));
  }
  ymax = Math.max(0.6, ymax);

  function plotLine(arr, stroke, width){
    ctx.strokeStyle = stroke;
    ctx.lineWidth = width;
    ctx.beginPath();
    for(let i=0;i<arr.length;i++){
      const x = padL + (i/(arr.length-1))*W;
      const y = padT + H - (arr[i]/ymax)*H;
      if(i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
    }
    ctx.stroke();
  }

  // plot reference curves
  for(const c1 of curves){
    plotLine(refData[c1.kind], c1.stroke, 2);
  }

  // overlay real training history (normalized) if available
  if(history && history.length){
    // Convert reward/value history to a "loss-like" curve for visualization.
    // If values are deltas (policy eval), they already behave like loss.
    const arr = history.slice(0,200);
    const maxv = Math.max(...arr.map(v=>Math.abs(v))) || 1;
    const norm = arr.map(v=>Math.abs(v)/maxv * 0.95 + 0.02);
    plotLine(norm, "#111827", 3);
  }

  // legend + highlight based on alpha
  // classify alpha into buckets
  let bucket = "good";
  const a = Number(alpha);
  if(a >= 0.8) bucket = "very_high";
  else if(a >= 0.3) bucket = "high";
  else if(a <= 0.05) bucket = "low";
  else bucket = "good";

  ctx.font="11px system-ui, -apple-system, Segoe UI, Roboto, Arial";
  let lx = padL + 6, ly = padT + 14;
  for(const c1 of curves){
    ctx.fillStyle = c1.stroke;
    ctx.fillRect(lx, ly-8, 10, 3);
    ctx.fillStyle = "#111827";
    const label = c1.label + (c1.kind===bucket ? "  ✓" : "");
    ctx.fillText(label, lx+14, ly-2);
    ly += 14;
  }
  ctx.fillStyle="#111827";
  ctx.fillText(`alpha (learning rate) = ${Number.isFinite(a)?a.toFixed(3):"?"}`, padL+W-180, padT+14);
}



function onEnvironmentChange(){
  // clear canvas on env change
  clearCanvas();
}

function tutorialHtml() {
  return `
  <h2>Reinforcement Learning Algorithms — Overview</h2>

  <p>
    This section explains the core <b>Reinforcement Learning (RL)</b> algorithms used in this project.
    Each algorithm differs in how it learns, whether it needs an environment model, and how it balances
    exploration and exploitation.
  </p>

  <h3>🔹 Policy Evaluation</h3>
  <p>
    <b>Policy Evaluation</b> computes the state-value function <code>V<sub>π</sub>(s)</code> for a
    <b>fixed policy</b> <code>π</code>.
  </p>
  <p><i>“If I keep following this policy forever, how good is each state?”</i></p>

  <ul>
    <li><b>Type:</b> Model-based</li>
    <li><b>Policy:</b> Fixed</li>
    <li><b>Learning:</b> Dynamic Programming</li>
    <li><b>Environment:</b> Requires full transition probabilities</li>
  </ul>

  <p><b>Bellman Expectation Update:</b></p>
  <pre><code>
V(s) ← ∑ₐ π(a|s) ∑ₛ′,ʳ P(s′, r | s, a) [ r + γ V(s′) ]
  </code></pre>

  <p><b>Algorithm Steps:</b></p>
  <ol>
    <li>Initialize <code>V(s) = 0</code> for all states</li>
    <li>Repeatedly update all states using the equation above</li>
    <li>Stop when value changes are sufficiently small</li>
  </ol>

  <h3>🔹 Policy Iteration</h3>
  <p>
    <b>Policy Iteration</b> alternates between evaluating a policy and improving it until the policy
    becomes optimal.
  </p>

  <ul>
    <li><b>Type:</b> Model-based</li>
    <li><b>Guarantee:</b> Converges to the optimal policy</li>
  </ul>

  <p><b>Policy Improvement Rule:</b></p>
  <pre><code>
π(s) = argmaxₐ ∑ₛ′,ʳ P(s′, r | s, a) [ r + γ V(s′) ]
  </code></pre>

  <p><b>Pros:</b> Fast convergence<br>
     <b>Cons:</b> Requires a full environment model</p>

  <h3>🔹 Value Iteration</h3>
  <p>
    <b>Value Iteration</b> directly computes the optimal value function without explicitly evaluating
    a policy.
  </p>

  <p><b>Bellman Optimality Update:</b></p>
  <pre><code>
V(s) ← maxₐ ∑ₛ′,ʳ P(s′, r | s, a) [ r + γ V(s′) ]
  </code></pre>

  <ul>
    <li>More efficient than Policy Iteration</li>
    <li>Still requires full model knowledge</li>
  </ul>

  <h3>🔹 Monte Carlo (MC)</h3>
  <p>
    <b>Monte Carlo methods</b> learn from complete episodes using actual experience.
  </p>

  <ul>
    <li><b>Type:</b> Model-free</li>
    <li><b>Update:</b> Only after episode ends</li>
  </ul>

  <pre><code>
V(s) ← V(s) + α ( G − V(s) )
  </code></pre>

  <p>
    <b>Pros:</b> No environment model needed<br>
    <b>Cons:</b> High variance, slow updates
  </p>

  <h3>🔹 Temporal Difference (TD)</h3>
  <p>
    <b>TD learning</b> updates values step-by-step without waiting for episode completion.
  </p>

  <pre><code>
V(s) ← V(s) + α [ r + γ V(s′) − V(s) ]
  </code></pre>

  <p>
    Combines ideas from Monte Carlo and Dynamic Programming.
  </p>

  <h3>🔹 N-Step TD</h3>
  <p>
    <b>N-step TD</b> balances between Monte Carlo and TD by looking ahead <code>n</code> steps.
  </p>

  <pre><code>
Gₜ⁽ⁿ⁾ = rₜ + γ rₜ₊₁ + ... + γⁿ V(sₜ₊ₙ)
  </code></pre>

  <ul>
    <li>Small <code>n</code> → TD-like</li>
    <li>Large <code>n</code> → MC-like</li>
  </ul>

  <h3>🔹 SARSA</h3>
  <p>
    <b>SARSA</b> is an <b>on-policy</b> TD control algorithm.
  </p>

  <pre><code>
Q(s,a) ← Q(s,a) + α [ r + γ Q(s′,a′) − Q(s,a) ]
  </code></pre>

  <p>
    Learns using the actual action taken, including exploration.
  </p>

  <h3>🔹 Q-Learning</h3>
  <p>
    <b>Q-learning</b> is an <b>off-policy</b> TD control algorithm that learns the optimal policy
    regardless of behavior.
  </p>

  <pre><code>
Q(s,a) ← Q(s,a) + α [ r + γ maxₐ′ Q(s′,a′) − Q(s,a) ]
  </code></pre>

  <table border="1" cellpadding="6">
    <tr>
      <th>Algorithm</th>
      <th>Policy Type</th>
    </tr>
    <tr>
      <td>SARSA</td>
      <td>On-policy</td>
    </tr>
    <tr>
      <td>Q-learning</td>
      <td>Off-policy</td>
    </tr>
  </table>

  <h3>🔹 Global Hyperparameters</h3>
  <ul>
    <li><b>Discount (γ):</b> Controls importance of future rewards</li>
    <li><b>Learning Rate (α):</b> Controls speed of learning</li>
    <li><b>Exploration (ε):</b> Probability of random action</li>
  </ul>

  <h3>🔹 Action Selection Strategies</h3>
  <ul>
    <li><b>Greedy:</b> Always best action (no exploration)</li>
    <li><b>ε-Greedy:</b> Random with probability ε</li>
    <li><b>Softmax:</b> Probabilistic action selection</li>
    <li><b>UCB:</b> Balances reward and uncertainty (bandits)</li>
  </ul>
  `;
}


function openTutorial(){
  $("tutorialBody").innerHTML = tutorialHtml();
  $("modalBackdrop").style.display = "flex";
}
function closeTutorial(){
  $("modalBackdrop").style.display = "none";
}

async function init(){
  // sliders
  bindSlider("learningRate","learningRateValue",(v)=>Number(v).toFixed(2));
  bindSlider("discountFactor","discountFactorValue",(v)=>Number(v).toFixed(2));
  bindSlider("explorationRate","explorationRateValue",(v)=>Number(v).toFixed(2));
  bindSlider("gridSize","gridSizeValue",(v)=>String(v));
  bindSlider("slipProb","slipProbValue",(v)=>Number(v).toFixed(2));
  bindSlider("maxSteps","maxStepsValue",(v)=>String(v));
  bindSlider("speed","speedValue",(v)=>String(v));

  // tutorial modal
  $("tutorialBtn").addEventListener("click", openTutorial);
  $("closeTutorial").addEventListener("click", closeTutorial);
  $("modalBackdrop").addEventListener("click", (e)=>{ if (e.target.id==="modalBackdrop") closeTutorial(); });

  // options from backend
  try{
    await fetchOptions();
    setStatus("Ready.");
  }catch(e){
    setStatus("Backend not reachable. Start FastAPI on 127.0.0.1:8000");
  }
}

init();
