from __future__ import annotations
from typing import Any, Dict, Optional
import math, random
from app.environments.base import BaseEnvironment

class MountainCar(BaseEnvironment):
    """Discretized MountainCar (classic control). Works with tabular and planning algorithms."""
    def __init__(self, pos_bins:int=18, vel_bins:int=14, maxSteps:int=200):
        self.pos_bins=int(pos_bins)
        self.vel_bins=int(vel_bins)
        self.max_steps=int(maxSteps)
        self.min_pos=-1.2
        self.max_pos=0.6
        self.min_vel=-0.07
        self.max_vel=0.07
        self.goal_pos=0.5
        self.reset()

    def reset(self, seed: Optional[int] = None)->int:
        if seed is not None:
            random.seed(int(seed))
        self.pos=random.uniform(-0.6,-0.4)
        self.vel=0.0
        self.t=0
        return self._discretize(self.pos,self.vel)

    def step(self, action:int):
        self.t += 1
        self.pos, self.vel, reward, done = self._transition(self.pos, self.vel, int(action), self.t)
        return self._discretize(self.pos,self.vel), reward, done, {"pos": float(self.pos), "vel": float(self.vel)}

    def _transition(self, pos:float, vel:float, action:int, t:int):
        force = (action-1)*0.001
        vel = vel + force - 0.0025*math.cos(3*pos)
        vel = max(self.min_vel, min(self.max_vel, vel))
        pos = pos + vel
        if pos < self.min_pos:
            pos = self.min_pos
            vel = 0.0
        done = pos >= self.goal_pos or t>=self.max_steps
        reward = 1.0 if pos >= self.goal_pos else -0.01
        return pos, vel, float(reward), bool(done)

    def get_state_space(self)->int:
        return self.pos_bins*self.vel_bins

    def get_action_space(self)->int:
        return 3

    def _bin(self, v, vmin, vmax, bins):
        r=(v-vmin)/(vmax-vmin)
        b=int(r*bins)
        return max(0, min(bins-1, b))

    def _discretize(self,pos,vel)->int:
        pb=self._bin(pos,self.min_pos,self.max_pos,self.pos_bins)
        vb=self._bin(vel,self.min_vel,self.max_vel,self.vel_bins)
        return vb*self.pos_bins + pb

    def _undiscretize(self,s:int):
        pb = s % self.pos_bins
        vb = s // self.pos_bins
        pos = self.min_pos + (pb+0.5)*(self.max_pos-self.min_pos)/self.pos_bins
        vel = self.min_vel + (vb+0.5)*(self.max_vel-self.min_vel)/self.vel_bins
        return pos, vel

    def state_to_xy(self,state:int):
        pos,_=self._undiscretize(int(state))
        x=(pos-self.min_pos)/(self.max_pos-self.min_pos)
        y=0.5*(math.sin(3*pos)+1.0)
        return float(x), float(y)

    def get_metadata(self)->Dict[str,Any]:
        return {
            "name":"MountainCar",
            "draw_mode":"mountain",
            "posBins": self.pos_bins,
            "velBins": self.vel_bins,
            "maxSteps": self.max_steps,
            "actions":["push_left","no_push","push_right"],
        }

    def get_transition_model(self):
        nS=self.get_state_space(); nA=self.get_action_space()
        P=[[[] for _ in range(nA)] for __ in range(nS)]
        for s in range(nS):
            pos,vel=self._undiscretize(s)
            for a in range(nA):
                npos,nvel,r,done = self._transition(pos,vel,a,1)
                ns=self._discretize(npos,nvel)
                # in planning, treat goal as terminal, ignore maxSteps
                P[s][a]=[(1.0, ns, float(r), bool(npos>=self.goal_pos))]
        return P