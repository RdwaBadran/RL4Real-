from __future__ import annotations

from typing import Any, Dict, Optional
from pydantic import BaseModel, Field


class TrainingRequest(BaseModel):
    environment: str = Field(..., description="Environment name, e.g. GridWorld")
    algorithm: str = Field(..., description="Algorithm name, e.g. q_learning")

    # New style: everything in params (used by current frontend)
    params: Dict[str, Any] = Field(default_factory=dict)

    # Backwards-compatible top-level fields
    episodes: Optional[int] = None
    alpha: Optional[float] = None
    gamma: Optional[float] = None
    epsilon: Optional[float] = None
    seed: Optional[int] = Field(default=None, description="Random seed for reproducibility")
