"""
Visualization Utilities
-----------------------
Backend-side helpers for formatting
visualization data if needed in future.
"""


def format_history(history):
    """
    Ensures history is JSON-serializable
    and frontend-friendly.
    """
    return history
