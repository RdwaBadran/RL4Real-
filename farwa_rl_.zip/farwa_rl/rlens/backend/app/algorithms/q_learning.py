from __future__ import annotations
from typing import Any, Dict, DefaultDict
from collections import defaultdict
import random
from app.algorithms.base import BaseRLAgent

class QLearning(BaseRLAgent):
    def __init__(self, n_states:int, n_actions:int, alpha:float=0.1, gamma:float=0.99, epsilon:float=0.1):
        super().__init__(n_states, n_actions, gamma)
        self.alpha=float(alpha)
        self.epsilon=float(epsilon)
        self.Q = defaultdict(lambda: [0.0]*self.n_actions)

    def act(self, state:int, greedy:bool=False, epsilon:float|None=None)->int:
        eps = 0.0 if greedy else (self.epsilon if epsilon is None else float(epsilon))
        if random.random() < eps:
            return random.randrange(self.n_actions)
        q=self.Q[int(state)]
        m=max(q)
        # tie break
        best=[i for i,v in enumerate(q) if v==m]
        return random.choice(best)

    def train(self, env, episodes:int=200, max_steps:int=200, **_)->Dict[str,Any]:
        returns=[]
        for ep in range(int(episodes)):
            s=env.reset()
            total=0.0
            for t in range(int(max_steps)):
                a=self.act(s, greedy=False)
                ns,r,done,_=env.step(a)
                total += r
                qsa=self.Q[s][a]
                target = r + (0.0 if done else self.gamma*max(self.Q[ns]))
                self.Q[s][a] = qsa + self.alpha*(target - qsa)
                s=ns
                if done: break
            returns.append(total)
        return {"episode_returns": returns}

    def get_policy(self):
        # greedy policy mapping for seen states
        policy={}
        for s,q in self.Q.items():
            m=max(q); best=[i for i,v in enumerate(q) if v==m]
            policy[int(s)]=best[0]
        return policy

def q_learning(env, **params):
    agent=QLearning(env.get_state_space(), env.get_action_space(),
                    alpha=params.get("alpha",0.1),
                    gamma=params.get("gamma",0.99),
                    epsilon=params.get("epsilon",0.1))
    hist=agent.train(env, episodes=params.get("episodes",200), max_steps=params.get("maxSteps",params.get("max_steps",200)))
    return agent, hist
