from __future__ import annotations
from typing import Any, Dict, List, Tuple
from collections import defaultdict
import random
from app.algorithms.base import BaseRLAgent

class MonteCarloControl(BaseRLAgent):
    """First-visit Monte Carlo control with epsilon-greedy policy."""
    def __init__(self, n_states:int, n_actions:int, gamma:float=0.99, epsilon:float=0.1):
        super().__init__(n_states,n_actions,gamma)
        self.epsilon=float(epsilon)
        self.Q=defaultdict(lambda:[0.0]*self.n_actions)
        self.N=defaultdict(lambda:[0]*self.n_actions)

    def act(self, state:int, greedy:bool=False, epsilon:float|None=None)->int:
        eps=0.0 if greedy else (self.epsilon if epsilon is None else float(epsilon))
        if random.random()<eps:
            return random.randrange(self.n_actions)
        q=self.Q[int(state)]
        m=max(q)
        best=[i for i,v in enumerate(q) if v==m]
        return random.choice(best)

    def train(self, env, episodes:int=200, max_steps:int=200, **_)->Dict[str,Any]:
        returns=[]
        for _ep in range(int(episodes)):
            s=env.reset()
            episode=[]
            total=0.0
            for _t in range(int(max_steps)):
                a=self.act(s)
                ns,r,done,_=env.step(a)
                episode.append((s,a,r))
                total += r
                s=ns
                if done: break
            # returns
            G=0.0
            seen=set()
            for (s,a,r) in reversed(episode):
                G = r + self.gamma*G
                if (s,a) in seen: 
                    continue
                seen.add((s,a))
                self.N[s][a]+=1
                n=self.N[s][a]
                self.Q[s][a] += (G-self.Q[s][a])/n
            returns.append(total)
        return {"episode_returns": returns}

    def get_policy(self):
        policy={}
        for s,q in self.Q.items():
            m=max(q); best=[i for i,v in enumerate(q) if v==m]
            policy[int(s)]=best[0]
        return policy
