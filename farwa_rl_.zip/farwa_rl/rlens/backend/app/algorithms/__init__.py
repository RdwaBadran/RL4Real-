from app.algorithms.q_learning import QLearning, q_learning
from app.algorithms.sarsa import SARSA
from app.algorithms.monte_carlo import MonteCarloControl
from app.algorithms.td import TDZero
from app.algorithms.n_step_td import NStepTD
from app.algorithms.value_iteration import ValueIteration
from app.algorithms.policy_iteration import PolicyIteration
from app.algorithms.policy_evaluation import PolicyEvaluation

ALGORITHM_REGISTRY = {
    "q_learning": QLearning,
    "sarsa": SARSA,
    "monte_carlo": MonteCarloControl,
    "td0": TDZero,
    "n_step_td": NStepTD,
    "value_iteration": ValueIteration,
    "policy_iteration": PolicyIteration,
    "policy_evaluation": PolicyEvaluation,
}
