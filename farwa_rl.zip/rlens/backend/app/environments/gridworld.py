from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple, Optional
import random
from app.environments.base import BaseEnvironment

@dataclass
class GridWorldConfig:
    size: int = 5
    slip_prob: float = 0.0
    max_steps: int = 200

class GridWorld(BaseEnvironment):
    """Square grid. Start at (0,0). Goal at (size-1,size-1)."""
    ACTIONS = [(0,-1),(1,0),(0,1),(-1,0)]  # up,right,down,left

    def __init__(self, gridSize: int = 5, slipProb: float = 0.0, maxSteps: int = 200):
        self.cfg = GridWorldConfig(size=int(gridSize), slip_prob=float(slipProb), max_steps=int(maxSteps))

        self.walls = self._default_walls(self.cfg.size)
        self.holes = self._default_holes(self.cfg.size)
        self.reset()

    def _encode(self, x:int,y:int)->int:
        return y*self.cfg.size + x

    def _decode(self, s:int)->Tuple[int,int]:
        return s%self.cfg.size, s//self.cfg.size

    def reset(self, seed: Optional[int] = None)->int:
        if seed is not None:
            random.seed(int(seed))
        self.x, self.y = 0,0
        self.t = 0
        return self._encode(self.x,self.y)

    def step(self, action:int):
        self.t += 1
        # slip: random action
        if random.random() < self.cfg.slip_prob:
            action = random.randrange(4)
        dx,dy = self.ACTIONS[int(action)]
        nx = min(self.cfg.size-1, max(0, self.x+dx))
        ny = min(self.cfg.size-1, max(0, self.y+dy))

        # Blocks + holes are impassable
        if (nx,ny) in self.walls or (nx,ny) in self.holes:
            nx,ny = self.x,self.y

        self.x,self.y = nx,ny
        done = (self.x==self.cfg.size-1 and self.y==self.cfg.size-1) or (self.t>=self.cfg.max_steps)
        reward = 1.0 if (self.x==self.cfg.size-1 and self.y==self.cfg.size-1) else -0.01
        return self._encode(self.x,self.y), reward, done, {}

    def get_state_space(self)->int:
        return self.cfg.size*self.cfg.size

    def get_action_space(self)->int:
        return 4

    def get_metadata(self)->Dict[str,Any]:
        return {
            "name":"GridWorld",
            "draw_mode":"grid",
            "gridSize": self.cfg.size,
            "slipProb": self.cfg.slip_prob,
            "maxSteps": self.cfg.max_steps,
            "actions":["up","right","down","left"],
            "start":{"x": 0, "y": 0},
            "goal":{"x": self.cfg.size-1, "y": self.cfg.size-1},
            "walls":[{"x":x,"y":y} for (x,y) in sorted(self.walls)],
            "holes":[{"x":x,"y":y} for (x,y) in sorted(self.holes)],
        }

    def state_to_xy(self, state:int):
        x,y = self._decode(int(state))
        return float(x), float(y)

    def get_transition_model(self):
        nS = self.get_state_space()
        nA = self.get_action_space()
        P = [[[] for _ in range(nA)] for __ in range(nS)]

        for s in range(nS):
            x, y = self._decode(s)
            terminal = (x == self.cfg.size-1 and y == self.cfg.size-1)
            for a in range(nA):
                if terminal:
                    P[s][a] = [(1.0, s, 0.0, True)]
                    continue

                outcomes = []
                # slip: intended action with prob (1-slip), otherwise uniform random
                probs = {a: 1.0 - self.cfg.slip_prob}
                if self.cfg.slip_prob > 0:
                    for ra in range(nA):
                        probs[ra] = probs.get(ra, 0.0) + self.cfg.slip_prob / nA

                for a2, prob in probs.items():
                    dx, dy = self.ACTIONS[int(a2)]
                    nx = min(self.cfg.size-1, max(0, x + dx))
                    ny = min(self.cfg.size-1, max(0, y + dy))

                    if (nx, ny) in self.walls or (nx, ny) in self.holes:
                        nx, ny = x, y

                    ns = self._encode(nx, ny)
                    done = (nx == self.cfg.size-1 and ny == self.cfg.size-1)
                    r = 1.0 if done else -0.01
                    outcomes.append((prob, ns, r, done))
                P[s][a] = outcomes
        return P

    @staticmethod
    def _default_walls(size: int) -> set[tuple[int,int]]:
        """Deterministic impassable blocks. Keep start (0,0) and goal clear."""
        walls:set[tuple[int,int]] = set()
        if size <= 4:
            return walls
        # A simple vertical wall with a gap
        x = size//2
        gap_y = size//2
        for y in range(size):
            if y == gap_y:
                continue
            walls.add((x, y))
        # A couple of extra blocks
        walls.update({(1, size-2), (size-2, 1)})
        walls.discard((0,0))
        walls.discard((size-1,size-1))
        return walls

    @staticmethod
    def _default_holes(size: int) -> set[tuple[int,int]]:
        """Deterministic holes (also impassable per your requirement)."""
        holes:set[tuple[int,int]] = set()
        if size <= 4:
            return holes
        candidates = [
            (2,1),
            (1,2),
            (size-3, size-2),
            (size-2, size-3),
        ]
        for x,y in candidates:
            if 0 <= x < size and 0 <= y < size:
                holes.add((x,y))
        holes.discard((0,0))
        holes.discard((size-1,size-1))
        return holes

    def _action_distribution(self, intended:int):
        sp = self.cfg.slip_prob
        if sp <= 0:
            return [(intended, 1.0)]
        other_prob = sp/3.0
        dist = []
        for a in range(4):
            dist.append((a, (1.0-sp) if a==intended else other_prob))
        return dist

    @staticmethod
    def _merge_outcomes(outcomes):
        acc = {}
        for p,ns,r,d in outcomes:
            key=(ns,r,d)
            acc[key]=acc.get(key,0.0)+p
        return [(p,ns,r,d) for (ns,r,d),p in acc.items()]