from __future__ import annotations
from typing import Any, Dict
from collections import defaultdict
import random
from app.algorithms.base import BaseRLAgent

class SARSA(BaseRLAgent):
    def __init__(self, n_states:int, n_actions:int, alpha:float=0.1, gamma:float=0.99, epsilon:float=0.1):
        super().__init__(n_states, n_actions, gamma)
        self.alpha=float(alpha)
        self.epsilon=float(epsilon)
        self.Q=defaultdict(lambda:[0.0]*self.n_actions)

    def act(self, state:int, greedy:bool=False, epsilon:float|None=None)->int:
        eps=0.0 if greedy else (self.epsilon if epsilon is None else float(epsilon))
        if random.random()<eps:
            return random.randrange(self.n_actions)
        q=self.Q[int(state)]
        m=max(q)
        best=[i for i,v in enumerate(q) if v==m]
        return random.choice(best)

    def train(self, env, episodes:int=200, max_steps:int=200, **_)->Dict[str,Any]:
        returns=[]
        for _ep in range(int(episodes)):
            s=env.reset()
            a=self.act(s)
            total=0.0
            for _t in range(int(max_steps)):
                ns,r,done,_=env.step(a)
                total += r
                na = self.act(ns) if not done else 0
                target = r + (0.0 if done else self.gamma*self.Q[ns][na])
                self.Q[s][a] += self.alpha*(target - self.Q[s][a])
                s,a=ns,na
                if done: break
            returns.append(total)
        return {"episode_returns": returns}

    def get_policy(self):
        policy={}
        for s,q in self.Q.items():
            m=max(q); best=[i for i,v in enumerate(q) if v==m]
            policy[int(s)]=best[0]
        return policy
