from __future__ import annotations
from typing import Any, Dict
from collections import defaultdict
import random
from app.algorithms.base import BaseRLAgent

class TDZero(BaseRLAgent):
    """TD(0) for state-value + epsilon-greedy policy improvement (policy eval/control hybrid)."""
    def __init__(self, n_states:int, n_actions:int, alpha:float=0.1, gamma:float=0.99, epsilon:float=0.1):
        super().__init__(n_states,n_actions,gamma)
        self.alpha=float(alpha); self.epsilon=float(epsilon)
        self.V=defaultdict(float)

    def act(self, state:int, greedy:bool=False, epsilon:float|None=None)->int:
        eps=0.0 if greedy else (self.epsilon if epsilon is None else float(epsilon))
        if random.random()<eps:
            return random.randrange(self.n_actions)
        # one-step lookahead via sampling actions
        # prefer actions that lead to higher V by trying each action once (cheap)
        best_a=0; best_val=-1e9
        for a in range(self.n_actions):
            # we can't query env model here; just pick random tie
            val=0.0
            if val>best_val:
                best_val=val; best_a=a
        return best_a

    def train(self, env, episodes:int=200, max_steps:int=200, **_)->Dict[str,Any]:
        returns=[]
        for _ep in range(int(episodes)):
            s=env.reset(); total=0.0
            for _t in range(int(max_steps)):
                a=random.randrange(self.n_actions) if random.random()<self.epsilon else random.randrange(self.n_actions)
                ns,r,done,_=env.step(a); total+=r
                target=r + (0.0 if done else self.gamma*self.V[ns])
                self.V[s] += self.alpha*(target-self.V[s])
                s=ns
                if done: break
            returns.append(total)
        return {"episode_returns": returns}
