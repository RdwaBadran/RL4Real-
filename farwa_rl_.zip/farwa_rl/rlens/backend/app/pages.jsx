import Playground from "@/pages/Playground"

export default function Page() {
  return <Playground />
}
